package com.example.tugasakhir.room

import androidx.lifecycle.LiveData
import com.example.tugaskahir.utils.AppExecutors

class JourneyRepository private constructor(private val appDao: JourneyDao, private val appExecutors: AppExecutors) {

    fun getAllJourney(): LiveData<List<JourneyEntity>> = appDao.getAllJourney()

    fun insertJourney(post: JourneyEntity) {
        appExecutors.diskIO().execute { appDao.insertJourney(post) }
    }

    fun updateJourney(post: JourneyEntity){
        appExecutors.diskIO().execute{appDao.updateJourney(post) }
    }

    fun deleteJourney(post: JourneyEntity){
        appExecutors.diskIO().execute{appDao.deleteJourney(post) }
    }

    companion object {
        @Volatile
        private var instance: JourneyRepository? = null

        fun getInstance(
            appDao: JourneyDao,
            appExecutors: AppExecutors
        ): JourneyRepository =
            instance ?: synchronized(this) {
                instance ?: JourneyRepository(appDao, appExecutors)
            }.also { instance=it}
    }
}