package com.example.tugasakhir.data

data class Review(
    val nama: String,
    val review: String,
    val rating: Double
)