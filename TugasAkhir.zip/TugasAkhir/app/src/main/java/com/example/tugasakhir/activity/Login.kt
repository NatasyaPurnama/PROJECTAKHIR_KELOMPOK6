package com.example.tugasakhir.activity

import android.content.Intent
import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.view.MotionEvent
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.tugasakhir.R
import android.widget.Toast
import com.example.tugasakhir.data.user

class Login : AppCompatActivity() {

    private lateinit var usernameInput: EditText
    private lateinit var passwordInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_login)

        usernameInput = findViewById(R.id.uUsername)
        passwordInput = findViewById(R.id.uPass)

        val loginBtn = findViewById<Button>(R.id.bLogin)

        loginBtn.setOnClickListener {
            if (validateInput()) {
                val username = usernameInput.text.toString()
                val password = passwordInput.text.toString()
                if (username == "MasJo" && password == "123") {
                    user.setUsername(username)
                    val intent = Intent(this, Home::class.java)
                    startActivity(intent)
                } else {
                    Toast.makeText(this, "Username atau password salah!", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun validateInput() : Boolean{
        var error = 0
        if(usernameInput.text.toString().isEmpty()) {
            error++
            usernameInput.error = "Masukkan Username Anda!"
        }
        if (passwordInput.text.toString().isEmpty()) {
            error++
            passwordInput.error = "Masukkan Password Anda!"
        }
        return error == 0
    }
}