package com.example.tugasakhir.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.tugasakhir.R
import com.example.tugasakhir.data.ListData
import com.example.tugasakhir.data.News
import com.example.tugasakhir.data.Review
import com.google.android.material.imageview.ShapeableImageView

class NewsAdapter (private val ListData: List<News>) : RecyclerView.Adapter<NewsAdapter.ViewHolder>() {
    private lateinit var onItemClickCallback: OnItemClickCallback

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: News)
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val kategori: TextView = itemView.findViewById(R.id.kategori)
        val title: TextView = itemView.findViewById(R.id.judul)
        val username: TextView = itemView.findViewById(R.id.namauser)
        val img: ShapeableImageView = itemView.findViewById(R.id.imgnews)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.item_news, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = ListData[position]

        holder.kategori.text = data.kategori
        holder.title.text = data.judul
        holder.username.text = data.username
        holder.img.setImageResource(data.gambar)
        holder.itemView.setOnClickListener { onItemClickCallback.onItemClicked(ListData[holder.adapterPosition]) }
    }

    override fun getItemCount(): Int = ListData.size

    private fun String.shorten(maxLength: Int): String {
        return if (this.length <= maxLength) this else "${this.substring(0, maxLength)}..."
    }
}