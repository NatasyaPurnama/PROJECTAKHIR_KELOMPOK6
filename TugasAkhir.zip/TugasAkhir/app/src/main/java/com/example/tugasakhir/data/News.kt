package com.example.tugasakhir.data

data class News(
    val kategori: String,
    val judul: String,
    val username: String,
    val gambar : Int
)