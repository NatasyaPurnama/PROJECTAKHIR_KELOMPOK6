package com.example.tugasakhir.data

data class Kategori(
    val kategori: String,
    val img: Int

)
