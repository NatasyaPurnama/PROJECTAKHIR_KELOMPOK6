package com.example.tugasakhir.data

data class Etika(
    val judul: String,
    val isi: String
)