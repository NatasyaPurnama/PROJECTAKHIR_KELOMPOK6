package com.example.tugasakhir.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.tugasakhir.R
import com.example.tugasakhir.data.Kategori

class ListAdapter (private val ListData: List<Kategori>) : RecyclerView.Adapter<ListAdapter.ViewHolder>() {
    private lateinit var onItemClickCallback: OnItemClickCallback
    private var selectedPosition = RecyclerView.NO_POSITION

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: Kategori)
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val kategori: TextView = itemView.findViewById(R.id.kategori)
        val ic: ImageView = itemView.findViewById(R.id.ic)
        val bg: CardView = itemView.findViewById(R.id.bg)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.item_kategori, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = ListData[position]
        holder.kategori.text = data.kategori
        holder.ic.setImageResource(data.img)

        if (position == selectedPosition) {
            holder.bg.setCardBackgroundColor(Color.parseColor("#142B55"))
            holder.kategori.setTextColor(Color.WHITE)
            holder.ic.setColorFilter(Color.WHITE)
        } else {
            holder.bg.setCardBackgroundColor(Color.WHITE)
            holder.kategori.setTextColor(Color.parseColor("#999999"))
            holder.ic.clearColorFilter()
        }

        holder.itemView.setOnClickListener {
            val previousPosition = selectedPosition
            selectedPosition = holder.adapterPosition
            notifyItemChanged(previousPosition)
            notifyItemChanged(selectedPosition)

            onItemClickCallback.onItemClicked(data)
        }
    }

    override fun getItemCount(): Int = ListData.size

    private fun String.shorten(maxLength: Int): String {
        return if (this.length <= maxLength) this else "${this.substring(0, maxLength)}..."
    }
}