package com.example.tugasakhir.activity

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import com.bumptech.glide.Glide
import com.example.tugasakhir.EditProfile
import com.example.tugasakhir.R
import com.example.tugasakhir.room.JourneyEntity
import com.google.android.material.bottomnavigation.BottomNavigationView

class Profile : AppCompatActivity() {
    private lateinit var edit: TextView
    private lateinit var namaUser1: TextView
    private lateinit var namaUser2: TextView
    private lateinit var emailUser1: TextView
    private lateinit var emailUser2: TextView
    private lateinit var addressUser: TextView
    private lateinit var phoneUser: TextView
    private lateinit var imgUser: ImageView
    private lateinit var logout: ImageView
    private lateinit var service: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        enableEdgeToEdge()

        edit = findViewById(R.id.edit)
        namaUser1 = findViewById(R.id.namaUser)
        namaUser2 = findViewById(R.id.nama)
        emailUser1 = findViewById(R.id.emailUser)
        emailUser2 = findViewById(R.id.email)
        addressUser = findViewById(R.id.address)
        phoneUser = findViewById(R.id.nohp)
        imgUser = findViewById(R.id.imgUser)
        logout = findViewById(R.id.masuk2)
        service = findViewById(R.id.masuk1)

        edit.setOnClickListener {
            Toast.makeText(this, "Maaf fitur edit belum tersedia", Toast.LENGTH_SHORT).show()
        }

        service.setOnClickListener {
            Toast.makeText(this, "Maaf fitur support belum tersedia", Toast.LENGTH_SHORT).show()
        }

        logout.setOnClickListener {
            val intent = Intent(this, Page1::class.java)
            startActivity(intent)
        }

        val username = "MasJo"
        val email = "Masjo123@mail.com"
        val alamat = "Jl. Raya Telang No. 123"
        val nohp = "+62 123-456-789"

        namaUser1.text = username
        namaUser2.text = username
        emailUser1.text = email
        emailUser2.text = email
        addressUser.text = alamat
        phoneUser.text = nohp
        Glide.with(this).load(R.drawable.masbro).into(imgUser)

        val bottomNav = findViewById<BottomNavigationView>(R.id.nav)
        bottomNav.setOnNavigationItemSelectedListener(navListener)

        bottomNav.selectedItemId = R.id.nav_profile
    }

    private val navListener = BottomNavigationView.OnNavigationItemSelectedListener { item: MenuItem ->
        when (item.itemId) {
            R.id.nav_profile -> {
                true
            }
            R.id.nav_home -> {
                val intent = Intent(this, Home::class.java)
                startActivity(intent)
                true
            }
            R.id.nav_explore -> {
                val intent = Intent(this, Explore::class.java)
                startActivity(intent)
                true
            }
            R.id.nav_ethics -> {
                val intent = Intent(this, Etika::class.java)
                startActivity(intent)
                true
            }
            R.id.nav_journey -> {
                val intent = Intent(this, Journey::class.java)
                startActivity(intent)
                true
            }
            else -> false
        }
    }
}