package com.example.tugasakhir.data.api

import android.os.Parcel
import android.os.Parcelable

data class APIResponse(
    val id: Int,
    val nama_wisata: String,
    val lokasi: String,
    val rating: String,
    val jam: String,
    val hargatiket: String,
    val cp: String,
    val fasilitas: String,
    val deskripsi: String,
    val gambar: String,
    val gambar2: String,
    val gambar3: String,
    val gambar4: String,
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readInt(),
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readString()!!
    )

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeInt(id)
        dest.writeString(nama_wisata)
        dest.writeString(lokasi)
        dest.writeString(rating)
        dest.writeString(jam)
        dest.writeString(hargatiket)
        dest.writeString(cp)
        dest.writeString(fasilitas)
        dest.writeString(deskripsi)
        dest.writeString(gambar)
        dest.writeString(gambar2)
        dest.writeString(gambar3)
        dest.writeString(gambar4)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<APIResponse> {
        override fun createFromParcel(source: Parcel): APIResponse {
            return APIResponse(source)
        }

        override fun newArray(size: Int): Array<APIResponse?> {
            return arrayOfNulls(size)
        }
    }
}
