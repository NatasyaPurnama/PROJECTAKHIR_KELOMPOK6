package com.example.tugasakhir.activity

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContentProviderCompat.requireContext
import com.bumptech.glide.Glide
import com.example.tugasakhir.R
import com.example.tugasakhir.crud.EditJourney
import com.example.tugasakhir.room.JourneyEntity

class DetailJourney : AppCompatActivity() {
    private lateinit var entity: JourneyEntity
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_journey)
        enableEdgeToEdge()

        val journey = intent.getParcelableExtra<JourneyEntity>("journey")

        val namaTempat: TextView = findViewById(R.id.nama_tempat)
        val isidesc: TextView = findViewById(R.id.isidesc)
        val lokasi: TextView = findViewById(R.id.lokasi)
        val rate: TextView = findViewById(R.id.rate)
        val image: ImageView = findViewById(R.id.bg)

        journey?.let {
            namaTempat.text = journey.name
            isidesc.text = journey.story
            rate.text = journey.rating
            lokasi.text = journey.location

            Glide.with(image)
                .load(journey.image)
                .into(image)
        }
    }

    fun balik(view: View) {
        val intent = Intent(view.context, Journey::class.java)
        view.context.startActivity(intent)
    }

    fun edit(view: View){
        val intent = Intent(this, EditJourney::class.java)
        intent.putExtra("data", entity)
        startActivity(intent)
    }
}
