package com.example.tugasakhir.data

import com.example.tugasakhir.R

object ListData {
    val ListReview = arrayListOf(
        Review(
            "Dewi Lestari",
            "Indah banget pemandangannya, fasilitasnya nyaman dipake, harga tiket ramah kantong.",
            4.7
        ),
        Review(
            "Budi Santoso",
            "Tempat yang sangat menenangkan dengan udara yang segar dan bersih. Sangat cocok untuk liburan keluarga.",
            3.4
        ),
        Review(
            "Siti Aisyah",
            "Lokasinya mudah dijangkau, banyak spot foto yang instagramable, dan banyak pilihan kuliner enak di sekitar.",
            4.9
        ),
        Review(
            "Andi Prasetyo",
            "Pengalaman yang luar biasa dengan pemandangan yang tidak terlupakan. Sangat direkomendasikan untuk para petualang.",
            4.2
        ),
        Review(
            "Ratna Dewi",
            "Pelayanan yang ramah dan profesional, fasilitasnya lengkap dan nyaman. Cocok untuk refreshing dari rutinitas sehari-hari.",
            4.9
        )
    )

    val ListNews = arrayListOf(
        News(
            "Flower Garden",
            "Kebun Raya Bogor, Wisata Alam Terindah",
            "Awkarin",
            R.drawable.kebuneuy
        ),
        News(
            "Waterfall",
            "12 Fenomena Menarik",
            "Rawrr",
            R.drawable.waterfall2
        ),
        News(
            "Lake",
            "Menikmati Keindahan Danau Toba di Sumatera Utara",
            "naturelover456",
            R.drawable.lake1
        ),
        News(
            "Mountain",
            "Petualangan Mendaki Gunung Rinjani di Lombok",
            "adventureseeker789",
            R.drawable.mountain1
        ),
        News(
            "Beach",
            "Liburan Seru di Pantai Kuta, Bali",
            "beachlover789",
            R.drawable.beach1
        ),
        News(
            "Cave",
            "Menjelajahi Keindahan Gua Jomblang di Yogyakarta",
            "explorer789",
            R.drawable.cave1
        ),
        News(
            "Island",
            "Menikmati Keindahan Pulau Komodo dan Kehidupan Liar",
            "adventureseeker789",
            R.drawable.island1
        )
    )

    val ListKategori = arrayListOf(
        Kategori(
            "Semua",
            0
        ),
        Kategori(
            "Danau",
            R.drawable.ic_lake
        ),
        Kategori(
            "Gunung",
            R.drawable.ic_mountain
        ),
        Kategori(
            "Pantai",
            R.drawable.ic_beach
        ),
        Kategori(
            "Air Terjun",
            R.drawable.ic_waterfall
        ),
        Kategori(
            "Goa",
            R.drawable.ic_cave
        ),
        Kategori(
            "Hutan",
            R.drawable.ic_forest
        ),
        Kategori(
            "Pulau",
            R.drawable.ic_island
        )
    )

    val ListEtika = arrayListOf(
        Etika(
            "Menghormati Kehidupan Liar",
            "1. Amati saja hewan liar jangan mendekati atau mengikutinya\n" +
                    "2. Lindungi kehidupan liar dan simpan makanan dan sampah di tempat aman dan jauh dari jangkauan hewan liat\n" +
                    "3. Jangan memberi makan hewan liar"
        ),
        Etika(
            "Persiapan dan Perencanaan",
            "1. Pelajari peraturan atau regulasi wilayah pegunungan yang akan didaki\n" +
                    "2. Jadwalkan pendakian dengan baik\n" +
                    "3. Persiapkan diri untuk cuaca ekstrim serta keadaan bahaya dan darurat\n" +
                    "4. Pastikan anda mempunyai keterampilan dan peralatan yang dibutuhkan"
        ),
        Etika(
            "Membuang limbah dengan benar",
            "1. Kemasi sampah dan sisa makanan yang anda bawa\n" +
                    "2. Timbun limbah padat manusia dengan kedalaman 6-8 inci\n" +
                    "3. Bawa kembali kertas toilet, produk kesehatan dan pemakaian pribadi lainnya"
        ),
        Etika(
            "1. Biarkan yang anda lihat dan temukan",
            "2. Lestarikan peninggalan masa lalu jangan menyentuh atau mengubah susunan artefak, situs atau peninggalan budaya dan sejarah\n" +
                    "3. Biarkan batu, tumbuhan dan objek lain sebagaimana anda melihatnya\n" +
                    "4. Jangan membuat bangunan yang bersifat permanen"
        ),
        Etika(
            "Etika Pendakian",
            "1. Jangan mengambil apapun selain gambar\n" +
                    "2. Jangan meninggalkan apapun kecuali jejak\n" +
                    "3. Jangan membunuh apapun selain waktu"
        )
    )
}