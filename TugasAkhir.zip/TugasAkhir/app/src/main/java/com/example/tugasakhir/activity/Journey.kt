package com.example.tugasakhir.activity

import JourneyAdapter
import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tugasakhir.crud.Popup
import com.example.tugasakhir.R
import com.example.tugasakhir.crud.AddJourney
import com.example.tugasakhir.data.user
import com.example.tugasakhir.room.JourneyEntity
import com.example.tugasakhir.room.JourneyViewModel
import com.example.tugasakhir.room.JourneyViewModelFactory
import com.google.android.material.bottomnavigation.BottomNavigationView

class Journey : AppCompatActivity() {
    private lateinit var appJourneyViewModel: JourneyViewModel
    private lateinit var journeyAdapter: JourneyAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var username: TextView
    private lateinit var notif: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_journey)
        notif = findViewById(R.id.notif)

        username = findViewById(R.id.hi)
        val nama = user?.getUsername() ?: "Ranger Alam"
        username.text = "Welcome, $nama!"

        data()

        val bottomNav = findViewById<BottomNavigationView>(R.id.nav)
        bottomNav.setOnNavigationItemSelectedListener(navListener)

        bottomNav.selectedItemId = R.id.nav_journey

        var notifOnOf = false
        notif.setOnClickListener{
            if (notifOnOf) {
                notifOnOf = false
                notif.setImageResource(R.drawable.ic_bell)
                Toast.makeText(this, "Fitur Notifikasi dimatikan", Toast.LENGTH_SHORT).show()
            } else {
                notifOnOf = true
                notif.setImageResource(R.drawable.ic_notifon)
                Toast.makeText(this, "Fitur Notifikasi diaktifkan", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun data(){
        val factory = JourneyViewModelFactory.getInstance(this)
        appJourneyViewModel = ViewModelProvider(this, factory)[JourneyViewModel::class.java]

        recyclerView = findViewById(R.id.rvJourney)
        recyclerView.layoutManager = GridLayoutManager(this,1)

        appJourneyViewModel.getAllJourney().observe(this) { postData ->
            if (postData != null) {
                journeyAdapter = JourneyAdapter(postData)
                recyclerView.adapter = journeyAdapter

                journeyAdapter.setOnItemClickCallback(object :
                    JourneyAdapter.OnItemClickCallback {
                    override fun onItemClicked(data: JourneyEntity) {
                        detail(data)
                    }

                    override fun onItemMore(data: JourneyEntity) {
                        Popup(data).show(supportFragmentManager, Popup.TAG)
                    }
                })
            }
        }
    }

    private val navListener = BottomNavigationView.OnNavigationItemSelectedListener { item: MenuItem ->
        when (item.itemId) {
            R.id.nav_journey -> {
                true
            }
            R.id.nav_home -> {
                val intent = Intent(this, Home::class.java)
                startActivity(intent)
                true
            }
            R.id.nav_explore -> {
                val intent = Intent(this, Explore::class.java)
                startActivity(intent)
                true
            }
            R.id.nav_ethics -> {
                startActivity(Intent(this, Etika::class.java))
                true
            }
            R.id.nav_profile -> {
                val intent = Intent(this, Profile::class.java)
                startActivity(intent)
                true
            }
            else -> false
        }
    }

    private fun detail(data: JourneyEntity) {
        val navigateToDetail = Intent(this, DetailJourney::class.java)
        navigateToDetail.putExtra("journey", data)
        startActivity(navigateToDetail)
    }


    fun addJourney(view: View) {
        val intent = Intent(this, AddJourney::class.java)
        startActivity(intent)
    }

    override fun onRestart() {
        super.onRestart()
        appJourneyViewModel.getAllJourney()
    }
}