package com.example.tugasakhir.room

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel

class JourneyViewModel(private val appRepository: JourneyRepository) : ViewModel() {

    fun insertJourney(post: JourneyEntity) {
        appRepository.insertJourney(post)
    }

    fun getAllJourney(): LiveData<List<JourneyEntity>> {
        return appRepository.getAllJourney()
    }

    fun updateJourney(post: JourneyEntity) {
        appRepository.updateJourney(post)
    }

    fun deleteJourney(post: JourneyEntity) {
        appRepository.deleteJourney(post)
    }
}