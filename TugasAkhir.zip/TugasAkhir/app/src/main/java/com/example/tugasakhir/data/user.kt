package com.example.tugasakhir.data

object user {
    private var username: String? = null
    fun setUsername(username: String) {
        this.username = username
    }

    fun getUsername(): String? {
        return username
    }
}