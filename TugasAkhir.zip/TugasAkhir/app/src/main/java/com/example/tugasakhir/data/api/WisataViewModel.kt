package com.example.tugasakhir.data.api

import androidx.lifecycle.ViewModel
import androidx.lifecycle.LiveData

class WisataViewModel(private val APIRepository: APIRepository) : ViewModel() {
    val listWisata: LiveData<List<APIResponse>> = APIRepository.listWisata
    val isLoading: LiveData<Boolean> = APIRepository.isLoading

    fun getAllWisata() {
        APIRepository.getAllWisata()
    }
}