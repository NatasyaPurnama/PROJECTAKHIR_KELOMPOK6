package com.example.tugasakhir.crud

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.esafirm.imagepicker.features.ImagePickerConfig
import com.esafirm.imagepicker.features.ImagePickerMode
import com.esafirm.imagepicker.features.ReturnMode
import com.esafirm.imagepicker.features.registerImagePicker
import com.example.tugasakhir.R
import com.example.tugasakhir.room.JourneyEntity
import com.example.tugasakhir.room.JourneyViewModel
import com.example.tugasakhir.room.JourneyViewModelFactory
import com.example.tugasakhir.utils.reduceFileImage
import com.example.tugasakhir.utils.uriToFile
import com.google.android.material.textfield.TextInputEditText
import java.io.File

class EditJourney : AppCompatActivity() {
    private var currentImageUri: Uri? = null
    private var imglama: File? = null

    private lateinit var iName: TextInputEditText
    private lateinit var iExperience: TextInputEditText
    private lateinit var iLocation: TextInputEditText
    private lateinit var iRating: TextInputEditText
    private lateinit var imgJourney: ImageView
    private lateinit var bGambar: ImageView
    private lateinit var bSave: Button

    private lateinit var journeyViewModel: JourneyViewModel
    private lateinit var getData: JourneyEntity

    private val imagePickerLauncher = registerImagePicker {
        val firstImage = it.firstOrNull() ?: return@registerImagePicker
        if (firstImage.uri.toString().isNotEmpty()) {
            bGambar.visibility = View.VISIBLE
            currentImageUri = firstImage.uri
            Glide.with(imgJourney)
                .load(firstImage.uri)
                .into(imgJourney)
        } else {
            imgJourney.visibility = View.GONE
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)
        enableEdgeToEdge()

        val factory = JourneyViewModelFactory.getInstance(this)
        journeyViewModel = ViewModelProvider(this, factory)[JourneyViewModel::class.java]

        getData = intent.getParcelableExtra("data")!!

        iName = findViewById(R.id.iName)
        iExperience = findViewById(R.id.iExperience)
        iLocation = findViewById(R.id.iLocation)
        iRating = findViewById(R.id.iRating)
        imgJourney = findViewById(R.id.imgJourney)

        bGambar = findViewById(R.id.bGaleri)
        bSave = findViewById(R.id.bSave)

        iName.setText(getData.name)
        iExperience.setText(getData.story)
        iLocation.setText(getData.location)
        iRating.setText(getData.rating)

        imglama = getData.image
        Glide.with(imgJourney)
            .load(getData.image)
            .into(imgJourney)

        bSave.setOnClickListener {
            if (validateInput()) {
                updateJourney()
            }
        }

        galeri()
    }

    private fun galeri() {
        bGambar.setOnClickListener {
            imagePickerLauncher.launch(
                ImagePickerConfig {
                    mode = ImagePickerMode.SINGLE
                    returnMode = ReturnMode.ALL
                    isFolderMode = true
                    folderTitle = "Galeri"
                    isShowCamera = false
                    imageTitle = "Tekan untuk memilih gambar"
                    doneButtonText = "Selesai"
                }
            )
        }
    }

    private fun validateInput(): Boolean {
        var isValid = true
        if (iName.text.isNullOrEmpty()) {
            iName.error = "Nama tidak boleh kosong"
            isValid = false
        }
        if (iExperience.text.isNullOrEmpty()) {
            iExperience.error = "Pengalaman tidak boleh kosong"
            isValid = false
        }
        if (iLocation.text.isNullOrEmpty()) {
            iLocation.error = "Lokasi tidak boleh kosong"
            isValid = false
        }
        if (iRating.text.isNullOrEmpty()) {
            iRating.error = "Rating tidak boleh kosong"
            isValid = false
        }
        if (currentImageUri == null) {
            Toast.makeText(this, "Mohon pilih gambar", Toast.LENGTH_SHORT).show()
            isValid = false
        }
        return isValid
    }

    private fun updateJourney() {
        val name = iName.text.toString()
        val experience = iExperience.text.toString()
        val location = iLocation.text.toString()
        val rating = iRating.text.toString()
        val imageFile = currentImageUri?.let { uriToFile(it, this).reduceFileImage() }

        if (imageFile != null) {
            val journey = JourneyEntity(
                id = getData.id,
                name = name,
                story = experience,
                location = location,
                rating = rating,
                image = imageFile
            )

            journeyViewModel.updateJourney(journey)

            Toast.makeText(this, "Journey berhasil diupdate", Toast.LENGTH_SHORT).show()
            finish()
        } else {
            Toast.makeText(this, "Mohon lengkapi data Journey", Toast.LENGTH_SHORT).show()
        }
    }
}
