package com.example.tugasakhir.activity

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tugasakhir.R
import com.example.tugasakhir.adapter.JHomeAdapter
import com.example.tugasakhir.adapter.ListAdapter
import com.example.tugasakhir.adapter.NewsAdapter
import com.example.tugasakhir.adapter.WisataAdapter
import com.example.tugasakhir.data.api.APIResponse
import com.example.tugasakhir.data.Kategori
import com.example.tugasakhir.data.ListData
import com.example.tugasakhir.data.News
import com.example.tugasakhir.data.api.WisataViewModel
import com.example.tugasakhir.data.api.WisataViewModelFactory
import com.example.tugasakhir.data.user
import com.example.tugasakhir.room.JourneyEntity
import com.example.tugasakhir.room.JourneyViewModel
import com.example.tugasakhir.room.JourneyViewModelFactory
import com.google.android.material.bottomnavigation.BottomNavigationView

class Home : AppCompatActivity() {

    private lateinit var appJourneyViewModel: JourneyViewModel
    private lateinit var wisataViewModel: WisataViewModel

    private lateinit var recyclerView1: RecyclerView
    private lateinit var recyclerView2: RecyclerView
    private lateinit var recyclerView3: RecyclerView
    private lateinit var recyclerView4: RecyclerView
    private lateinit var kategoriAdapter: ListAdapter
    private lateinit var wisataAdapter: WisataAdapter
    private lateinit var journeyAdapter: JHomeAdapter
    private lateinit var newsAdapter: NewsAdapter
    private lateinit var username: TextView
    private lateinit var searchBar: EditText
    private lateinit var bSearch: Button


    private lateinit var notif: ImageView
    private lateinit var more1: TextView
    private lateinit var more2: TextView
    private lateinit var bEtika: CardView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home)
        searchBar = findViewById(R.id.iSearch)
        bSearch = findViewById(R.id.bSearch)
        more1 = findViewById(R.id.all)
        more2 = findViewById(R.id.allnews)
        bEtika = findViewById(R.id.imgetika)
        notif = findViewById(R.id.ic_notifOy)

        username = findViewById(R.id.hi)
        val nama = user?.getUsername() ?: "Ranger Alam"
        username.text = "Welcome, $nama!"

        redirectygy()
        searchBar()
        recyclerview()
        navigasi()
    }

    private fun redirectygy(){
        var notifOnOf = false
        more1.setOnClickListener {
            val intent = Intent(this, Journey::class.java)
            startActivity(intent)
        }

        more2.setOnClickListener{
            Toast.makeText(this, "Maaf fitur lihat semua berita belum tersedia", Toast.LENGTH_SHORT).show()
        }

        notif.setOnClickListener{
            if (notifOnOf) {
                notifOnOf = false
                notif.setImageResource(R.drawable.ic_bell)
                Toast.makeText(this, "Fitur Notifikasi dimatikan", Toast.LENGTH_SHORT).show()
            } else {
                notifOnOf = true
                notif.setImageResource(R.drawable.ic_notifon)
                Toast.makeText(this, "Fitur Notifikasi diaktifkan", Toast.LENGTH_SHORT).show()
            }
        }

        bEtika.setOnClickListener {
            val intent = Intent(this, Etika::class.java)
            startActivity(intent)
        }
    }

    private fun recyclerview() {
        recyclerView1 = findViewById(R.id.rvKategori)
        recyclerView2 = findViewById(R.id.rvNews)
        recyclerView3 = findViewById(R.id.rvWisata)
        recyclerView4 = findViewById(R.id.rvJourney)

        kategoriAdapter = ListAdapter(ListData.ListKategori)
        recyclerView1.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        recyclerView1.adapter = kategoriAdapter

        kategoriAdapter.setOnItemClickCallback(object : ListAdapter.OnItemClickCallback {
            override fun onItemClicked(data: Kategori) {
                when (data.kategori) {
                    "Semua" -> filterKategori(listOf(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42))
                    "Danau" -> filterKategori(listOf(1, 2, 3, 4, 5, 6))
                    "Gunung" -> filterKategori(listOf(7, 8, 9, 10, 11, 12))
                    "Pantai" -> filterKategori(listOf(13, 14, 15, 16, 17, 18))
                    "Air Terjun" -> filterKategori(listOf(19, 20, 21, 22, 23, 24))
                    "Goa" -> filterKategori(listOf(25, 26, 27, 28, 29, 30))
                    "Hutan" -> filterKategori(listOf(31, 32, 33, 34, 35, 36))
                    "Pulau" -> filterKategori(listOf(37, 38, 39, 40, 41, 42))
                    else -> wisataViewModel.getAllWisata()
                }
            }
        })

        newsAdapter = NewsAdapter(ListData.ListNews)
        recyclerView2.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        recyclerView2.adapter = newsAdapter

        newsAdapter.setOnItemClickCallback(object : NewsAdapter.OnItemClickCallback {
            override fun onItemClicked(data: News) {
            }
        })

        val factory = WisataViewModelFactory.getInstance()
        wisataViewModel = ViewModelProvider(this, factory)[WisataViewModel::class.java]
        recyclerView3.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        wisataViewModel.getAllWisata()
        wisataViewModel.listWisata.observe(this) { data ->
            if (data.isNotEmpty()) {
                wisataAdapter = WisataAdapter(data)
                recyclerView3.adapter = wisataAdapter
                wisataAdapter.setOnItemClickCallback(object :
                    WisataAdapter.OnItemClickCallback {
                    override fun onItemClicked(data: APIResponse) {
                        detail(data)
                    }
                })
            }
        }

        val factory2 = JourneyViewModelFactory.getInstance(this)
        appJourneyViewModel = ViewModelProvider(this, factory2)[JourneyViewModel::class.java]
        recyclerView4.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)

        appJourneyViewModel.getAllJourney().observe(this) { postData ->
            if (postData != null) {
                journeyAdapter = JHomeAdapter(postData)
                recyclerView4.adapter = journeyAdapter

                journeyAdapter.setOnItemClickCallback(object :
                    JHomeAdapter.OnItemClickCallback {
                    override fun onItemClicked(data: JourneyEntity) {
                        detailjourney(data)
                    }
                })
            }
        }
    }

    private fun searchBar() {
        bSearch.setOnClickListener {
            val nama = searchBar.text.toString()
            val lokasi = searchBar.text.toString()
            if (nama.isNotEmpty()) {
                filterNama(nama)
            } else if (lokasi.isNotEmpty()) {
                filterLokasi(lokasi)
            } else {
                Toast.makeText(this, "Masukkan nama atau lokasi untuk pencarian", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun filterNama(name: String) {
        wisataViewModel.listWisata.observe(this) { data ->
            val filteredData = data.filter { it.nama_wisata.contains(name, ignoreCase = true) }
            if (filteredData.isNotEmpty()) {
                wisataAdapter = WisataAdapter(filteredData)
                recyclerView3.adapter = wisataAdapter
                wisataAdapter.setOnItemClickCallback(object :
                    WisataAdapter.OnItemClickCallback {
                    override fun onItemClicked(data: APIResponse) {
                        detail(data)
                    }
                })
            } else {
                Toast.makeText(this, "$name tidak ditemukan", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun filterLokasi(location: String) {
        wisataViewModel.listWisata.observe(this) { data ->
            val filteredData = data.filter { it.lokasi.contains(location, ignoreCase = true) }
            if (filteredData.isNotEmpty()) {
                wisataAdapter = WisataAdapter(filteredData)
                recyclerView3.adapter = wisataAdapter
                wisataAdapter.setOnItemClickCallback(object :
                    WisataAdapter.OnItemClickCallback {
                    override fun onItemClicked(data: APIResponse) {
                        detail(data)
                    }
                })
            } else {
                Toast.makeText(this, "$location tidak ditemukan", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun filterKategori(id: List<Int>) {
        wisataViewModel.listWisata.observe(this) { data ->
            val filteredData = data.filter { it.id in id }
            if (filteredData.isNotEmpty()) {
                wisataAdapter = WisataAdapter(filteredData)
                recyclerView3.adapter = wisataAdapter
                wisataAdapter.setOnItemClickCallback(object :
                    WisataAdapter.OnItemClickCallback {
                    override fun onItemClicked(data: APIResponse) {
                        detail(data)
                    }
                })
            }
        }
    }

    private fun detailjourney(data: JourneyEntity) {
        val navigateToDetail = Intent(this, DetailJourney::class.java)
        navigateToDetail.putExtra("journey", data)
        startActivity(navigateToDetail)
    }

    private fun detail(data: APIResponse) {
        val navigateToDetail = Intent(this, DetailWisata::class.java)
        navigateToDetail.putExtra("data", data)
        startActivity(navigateToDetail)
    }

    private fun navigasi() {
        val bottomNav = findViewById<BottomNavigationView>(R.id.nav)
        bottomNav.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> true
                R.id.nav_explore -> {
                    startActivity(Intent(this, Explore::class.java))
                    true
                }
                R.id.nav_journey -> {
                    startActivity(Intent(this, Journey::class.java))
                    true
                }
                R.id.nav_ethics -> {
                    startActivity(Intent(this, Etika::class.java))
                    true
                }
                R.id.nav_profile -> {
                    startActivity(Intent(this, Profile::class.java))
                    true
                }
                else -> false
            }
        }
    }

    override fun onRestart() {
        super.onRestart()
        appJourneyViewModel.getAllJourney()
    }
}