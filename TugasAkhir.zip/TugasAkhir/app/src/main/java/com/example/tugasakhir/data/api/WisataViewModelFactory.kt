package com.example.tugasakhir.data.api

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

class WisataViewModelFactory private constructor(private val repository: APIRepository) :
    ViewModelProvider.NewInstanceFactory() {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(WisataViewModel::class.java)) {
            return WisataViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown WisataViewModel class: " + modelClass.name)
    }
    companion object {
        @Volatile
        private var instance: WisataViewModelFactory? = null

        fun getInstance(): WisataViewModelFactory = instance ?: synchronized(this) {
                instance ?: WisataViewModelFactory(APIRepository())
        }.also { instance = it }
    }
}