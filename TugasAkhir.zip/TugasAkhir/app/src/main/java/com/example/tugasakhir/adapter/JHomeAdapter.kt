package com.example.tugasakhir.adapter

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.tugasakhir.R
import com.example.tugasakhir.room.JourneyEntity

class JHomeAdapter (private var journeyList: List<JourneyEntity>) :
    RecyclerView.Adapter<JHomeAdapter.JourneyViewHolder>() {

    private lateinit var onItemClickCallback: OnItemClickCallback

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: JourneyEntity)
    }

    class JourneyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: TextView = itemView.findViewById(R.id.namaWisata)
        val loc: TextView = itemView.findViewById(R.id.lokasiWisata)
        val rate: TextView = itemView.findViewById(R.id.ratingWisata)
        val img: ImageView = itemView.findViewById(R.id.imgWisata)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JourneyViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.item_journey, parent, false)
        return JourneyViewHolder(view)
    }

    override fun onBindViewHolder(holder: JourneyViewHolder, position: Int) {
        val data = journeyList[position]

        holder.title.text = data.name
        holder.loc.text = data.location
        holder.rate.text = data.rating

        val uri = Uri.fromFile(data.image)
        holder.img.setImageURI(uri)

        holder.itemView.setOnClickListener {
            onItemClickCallback.onItemClicked(journeyList[holder.bindingAdapterPosition])
        }
    }

    override fun getItemCount(): Int = journeyList.size
}
