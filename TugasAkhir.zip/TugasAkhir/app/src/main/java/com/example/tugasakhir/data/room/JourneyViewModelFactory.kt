package com.example.tugasakhir.room

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.tugasakhir.utils.DependencyInjection

class JourneyViewModelFactory private constructor(private val appRepository: JourneyRepository) :
    ViewModelProvider.NewInstanceFactory() {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(JourneyViewModel::class.java)) {
            return JourneyViewModel(appRepository) as T
        }
        throw IllegalArgumentException("Unknown AllViewModel class: " + modelClass.name)
    }

    companion object {
        @Volatile
        private var instance: JourneyViewModelFactory? = null
        fun getInstance(context: Context): JourneyViewModelFactory =
            instance ?: synchronized(this) {
                instance ?: JourneyViewModelFactory(DependencyInjection.provideRepository(context))
            }.also { instance=it}
    }
}