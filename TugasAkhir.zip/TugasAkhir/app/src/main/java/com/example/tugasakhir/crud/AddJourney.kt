package com.example.tugasakhir.crud

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.esafirm.imagepicker.features.ImagePickerConfig
import com.esafirm.imagepicker.features.ImagePickerMode
import com.esafirm.imagepicker.features.ReturnMode
import com.esafirm.imagepicker.features.registerImagePicker
import com.example.tugasakhir.R
import com.example.tugasakhir.activity.Journey
import com.example.tugasakhir.room.JourneyEntity
import com.example.tugasakhir.room.JourneyViewModel
import com.example.tugasakhir.room.JourneyViewModelFactory
import com.example.tugasakhir.utils.reduceFileImage
import com.example.tugasakhir.utils.uriToFile
import com.google.android.material.textfield.TextInputEditText

class AddJourney : AppCompatActivity() {
    private lateinit var iName: TextInputEditText
    private lateinit var iExperience: TextInputEditText
    private lateinit var iLocation: TextInputEditText
    private lateinit var iRating: TextInputEditText
    private lateinit var imgJourney: ImageView
    private lateinit var bGambar: ImageView
    private lateinit var bSave: Button

    private var currentImageUri: Uri? = null

    private lateinit var journeyViewModel: JourneyViewModel

    private val imagePickerLauncher = registerImagePicker {
        val firstImage = it.firstOrNull() ?: return@registerImagePicker
        if (firstImage.uri.toString().isNotEmpty()) {
            bGambar.visibility = View.VISIBLE
            currentImageUri = firstImage.uri
            Glide.with(imgJourney)
                .load(firstImage.uri)
                .into(imgJourney)
        } else {
            imgJourney.visibility = View.GONE
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_journey)
        enableEdgeToEdge()

        val factory = JourneyViewModelFactory.getInstance(this)
        journeyViewModel = ViewModelProvider(this, factory)[JourneyViewModel::class.java]

        iName = findViewById(R.id.iName)
        iExperience = findViewById(R.id.iExperience)
        iLocation = findViewById(R.id.iLocation)
        iRating = findViewById(R.id.iRating)
        imgJourney = findViewById(R.id.imgJourney)

        bGambar = findViewById(R.id.bGaleri)
        bSave = findViewById(R.id.bSave)

        galeri()

        bSave.setOnClickListener {
            if (validateInput()) {
                savedData()
            }
        }
    }

    private fun validateInput(): Boolean {
        var error = 0
        if (iName.text.toString().isEmpty()) {
            error++
            iName.error = "Nama tidak boleh kosong"
        }
        if (iExperience.text.toString().isEmpty()) {
            error++
            iExperience.error = "Pengalaman tidak boleh kosong"
        }
        if (iLocation.text.toString().isEmpty()) {
            error++
            iLocation.error = "Lokasi tidak boleh kosong"
        }
        if (iRating.text.toString().isEmpty()) {
            error++
            iRating.error = "Rating tidak boleh kosong"
        }
        if (currentImageUri == null) {
            error++
            Toast.makeText(this, "Mohon pilih gambar", Toast.LENGTH_SHORT).show()
        }
        return error == 0
    }

    private fun galeri() {
        bGambar.setOnClickListener {
            imagePickerLauncher.launch(
                ImagePickerConfig {
                    mode = ImagePickerMode.SINGLE
                    returnMode = ReturnMode.ALL
                    isFolderMode = true
                    folderTitle = "Galeri"
                    isShowCamera = false
                    imageTitle = "Tekan untuk memilih gambar"
                    doneButtonText = "Selesai"
                }
            )
        }
    }

    private fun savedData() {
        val name = iName.text.toString()
        val experience = iExperience.text.toString()
        val location = iLocation.text.toString()
        val rating = iRating.text.toString()
        val imageFile = currentImageUri?.let { uriToFile(it, this).reduceFileImage() }

        if (experience.isNotEmpty() && location.isNotEmpty() && rating != null && imageFile != null) {
            val journey = JourneyEntity(
                id = 0,
                name = name,
                story = experience,
                location = location,
                rating = rating,
                image = imageFile
            )
            journeyViewModel.insertJourney(journey)

            Toast.makeText(this, "Journey berhasil disimpan", Toast.LENGTH_SHORT).show()
            finish()
        } else {
            Toast.makeText(this, "Mohon lengkapi data Journey", Toast.LENGTH_SHORT).show()
        }
    }

    fun balik(view: View) {
        val intent = Intent(this, Journey::class.java)
        startActivity(intent)
    }
}