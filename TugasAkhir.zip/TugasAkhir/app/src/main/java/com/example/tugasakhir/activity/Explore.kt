package com.example.tugasakhir.activity

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tugasakhir.R
import com.example.tugasakhir.adapter.ListAdapter
import com.example.tugasakhir.adapter.WisataAdapter
import com.example.tugasakhir.data.Kategori
import com.example.tugasakhir.data.ListData
import com.example.tugasakhir.data.api.APIResponse
import com.example.tugasakhir.data.api.WisataViewModel
import com.example.tugasakhir.data.api.WisataViewModelFactory
import com.example.tugasakhir.data.user
import com.google.android.material.bottomnavigation.BottomNavigationView

class Explore : AppCompatActivity() {
    private lateinit var username: TextView
    private lateinit var wisataViewModel: WisataViewModel
    private lateinit var recyclerView1: RecyclerView
    private lateinit var recyclerView3: RecyclerView
    private lateinit var wisataAdapter: WisataAdapter
    private lateinit var kategoriAdapter: ListAdapter
    private lateinit var notif: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_explore)
        notif = findViewById(R.id.notif)


        username = findViewById(R.id.hi)
        val nama = user?.getUsername() ?: "Ranger Alam"
        username.text = "Welcome, $nama!"

        data()

        val bottomNav = findViewById<BottomNavigationView>(R.id.nav)
        bottomNav.setOnNavigationItemSelectedListener(navListener)
        bottomNav.selectedItemId = R.id.nav_explore

        var notifOnOf = false
        notif.setOnClickListener{
            if (notifOnOf) {
                notifOnOf = false
                notif.setImageResource(R.drawable.ic_bell)
                Toast.makeText(this, "Fitur Notifikasi dimatikan", Toast.LENGTH_SHORT).show()
            } else {
                notifOnOf = true
                notif.setImageResource(R.drawable.ic_notifon)
                Toast.makeText(this, "Fitur Notifikasi diaktifkan", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun data(){
        recyclerView1 = findViewById(R.id.rvKategori)
        recyclerView3 = findViewById(R.id.rvEksplor)

        kategoriAdapter = ListAdapter(ListData.ListKategori)
        recyclerView1.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        recyclerView1.adapter = kategoriAdapter

        kategoriAdapter.setOnItemClickCallback(object : ListAdapter.OnItemClickCallback {
            override fun onItemClicked(data: Kategori) {
                when (data.kategori) {
                    "Semua" -> filter(listOf(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42))
                    "Danau" -> filter(listOf(1, 2, 3, 4, 5, 6))
                    "Gunung" -> filter(listOf(7, 8, 9, 10, 11, 12))
                    "Pantai" -> filter(listOf(13, 14, 15, 16, 17, 18))
                    "Air Terjun" -> filter(listOf(19, 20, 21, 22, 23, 24))
                    "Goa" -> filter(listOf(25, 26, 27, 28, 29, 30))
                    "Hutan" -> filter(listOf(31, 32, 33, 34, 35, 36))
                    "Pulau" -> filter(listOf(37, 38, 39, 40, 41, 42))
                    else -> wisataViewModel.getAllWisata()
                }
            }
        })

        val factory = WisataViewModelFactory.getInstance()
        wisataViewModel = ViewModelProvider(this, factory)[WisataViewModel::class.java]
        recyclerView3.layoutManager = GridLayoutManager(this, 2)
        wisataViewModel.getAllWisata()
        wisataViewModel.listWisata.observe(this) { data ->
            if (data.isNotEmpty()) {
                wisataAdapter = WisataAdapter(data)
                recyclerView3.adapter = wisataAdapter
                wisataAdapter.setOnItemClickCallback(object :
                    WisataAdapter.OnItemClickCallback {
                    override fun onItemClicked(data: APIResponse) {
                        detail(data)
                    }
                })
            }
        }
    }

    private fun filter(id: List<Int>) {
        wisataViewModel.listWisata.observe(this) { data ->
            val filteredData = data.filter { it.id in id }
            if (filteredData.isNotEmpty()) {
                wisataAdapter = WisataAdapter(filteredData)
                recyclerView3.adapter = wisataAdapter
                wisataAdapter.setOnItemClickCallback(object :
                    WisataAdapter.OnItemClickCallback {
                    override fun onItemClicked(data: APIResponse) {
                        detail(data)
                    }
                })
            }
        }
    }

    private fun detail(data: APIResponse) {
        val navigateToDetail = Intent(this, DetailWisata::class.java)
        navigateToDetail.putExtra("data", data)
        startActivity(navigateToDetail)
    }

    private val navListener = BottomNavigationView.OnNavigationItemSelectedListener { item: MenuItem ->
        when (item.itemId) {
            R.id.nav_explore -> {
                true
            }
            R.id.nav_home -> {
                val intent = Intent(this, Home::class.java)
                startActivity(intent)
                true
            }
                R.id.nav_journey -> {
                    val intent = Intent(this, Journey::class.java)
                    startActivity(intent)
                    true
                }
                R.id.nav_ethics -> {
                    val intent = Intent(this, Etika::class.java)
                    startActivity(intent)
                    true
                }
                R.id.nav_profile -> {
                    val intent = Intent(this, Profile::class.java)
                    startActivity(intent)
                    true
                }
            else -> false
        }
    }
}