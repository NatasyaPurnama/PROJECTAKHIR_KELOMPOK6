package com.example.tugasakhir.data.api

import retrofit2.Call
import retrofit2.http.GET

interface APIService {
    @GET("wisata")
    fun getAllWisata(): Call<List<APIResponse>>
}