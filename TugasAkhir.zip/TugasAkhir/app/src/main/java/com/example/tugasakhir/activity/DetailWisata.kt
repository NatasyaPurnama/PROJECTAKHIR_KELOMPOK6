package com.example.tugasakhir.activity

import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.denzcoskun.imageslider.ImageSlider
import com.denzcoskun.imageslider.constants.ScaleTypes
import com.denzcoskun.imageslider.models.SlideModel
import com.example.tugasakhir.R
import com.example.tugasakhir.adapter.ReviewAdapter
import com.example.tugasakhir.data.ListData
import com.example.tugasakhir.data.api.APIResponse
import com.google.android.material.imageview.ShapeableImageView
import java.io.ByteArrayOutputStream

class DetailWisata : AppCompatActivity() {
    private var isLoved = false
    private lateinit var itemReview: ReviewAdapter
    private lateinit var recyclerView: RecyclerView
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_detail_wisata)

        share()
        data()
        review()
        map()
    }

    private fun map(){
        val bMap = findViewById<ImageView>(R.id.bMap)
        bMap.setOnClickListener {
            val asal = "Universitas+Trunojoyo+Madura"
            val tujuan = intent.getParcelableExtra<APIResponse>("data")
            if (tujuan != null) {
                gmap(asal, tujuan.nama_wisata)
            } else {
                Toast.makeText(this, "Objek APIResponse null", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun data(){
        val getData = intent.getParcelableExtra<APIResponse>("data")!!

        val nama_tempat: TextView = findViewById(R.id.nama_tempat)
        val lokasi: TextView = findViewById(R.id.lokasi)
        val rate: TextView = findViewById(R.id.rate)
        val jam: TextView = findViewById(R.id.jam)
        val harga: TextView = findViewById(R.id.harga)
        val cp: TextView = findViewById(R.id.nohp)
        val fasilitas: TextView = findViewById(R.id.fasilitas)
        val deskripsi: TextView = findViewById(R.id.isidesc)
        val share: ImageView = findViewById(R.id.share)

        nama_tempat.text = getData.nama_wisata
        lokasi.text = getData.lokasi
        rate.text = getData.rating
        jam.text = getData.jam
        cp.text = getData.cp
        fasilitas.text = getData.fasilitas
        deskripsi.text = getData.deskripsi
        deskripsi.text = getData.deskripsi
        harga.text = getData.hargatiket

        val imgSlider = findViewById<ImageSlider>(R.id.imgslider)
        val imgList = ArrayList<SlideModel>()

        imgList.add(SlideModel(getData.gambar))
        imgList.add(SlideModel(getData.gambar2))
        imgList.add(SlideModel(getData.gambar3))
        imgList.add(SlideModel(getData.gambar4))
        imgSlider.setImageList(imgList, ScaleTypes.FIT)

        share.setOnClickListener {
            if (isLoved) {
                share.setImageResource(R.drawable.ic_share)
                isLoved = false
            } else {
                share.setImageResource(R.drawable.ic_bshare)
                isLoved = true
            }
        }
    }

    private fun share(){
        val getData = intent.getParcelableExtra<APIResponse>("data")!!
        val bShare = findViewById<ImageView>(R.id.share)

        bShare.setOnClickListener {
            val sendIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT,
                    "Yuk, Mulailah Perjalanan Anda Menuju Kebahagiaan dengan Menjelajahi Surga di Bumi! ${getData?.nama_wisata}\nDeskripsi: ${getData?.deskripsi}")
                val bitmap = Glide.with(this@DetailWisata)
                    .asBitmap()
                    .load(getData?.gambar)
                    .submit()
                    .get()
                type = "image/jpeg"
                putExtra(Intent.EXTRA_STREAM, BitmapkeUri(bitmap))
            }

            Log.d("DetailWisata", "SendIntent: $sendIntent")

            val whatsappInstalled =
                isPackageInstalled("com.whatsapp") || isPackageInstalled("com.whatsapp.web")
            if (whatsappInstalled) {
                sendIntent.setPackage("com.whatsapp")
                startActivity(sendIntent)
            } else {
                Toast.makeText(this, "WhatsApp tidak terinstal.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun gmap(asal: String, tujuan: String) {
        try {
            val uri = Uri.parse("https://www.google.co.in/maps/dir/$asal/$tujuan")
            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.setPackage("com.google.android.apps.maps")
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            val uri =
                Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.apps")
            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }
    }

    private fun BitmapkeUri(bitmap: Bitmap): Uri? {
        val byte = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byte)
        val path = MediaStore.Images.Media.insertImage(contentResolver, bitmap, "Wisata Image", null)
        return path?.let { Uri.parse(it) }
    }

    private fun isPackageInstalled(packageName: String): Boolean {
        return try {
            packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    private fun review(){
        recyclerView = findViewById(R.id.rvreview)
        itemReview = ReviewAdapter(ListData.ListReview)
        recyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        recyclerView.adapter = itemReview
    }

    fun balik(view: View) {
        val intent = Intent(view.context, Explore::class.java)
        view.context.startActivity(intent)
    }
}