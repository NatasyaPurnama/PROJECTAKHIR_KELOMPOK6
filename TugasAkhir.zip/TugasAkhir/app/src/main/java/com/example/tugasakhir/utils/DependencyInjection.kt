package com.example.tugasakhir.utils

import android.content.Context
import com.example.tugasakhir.room.AppDatabase
import com.example.tugasakhir.room.JourneyRepository
import com.example.tugaskahir.utils.AppExecutors

object DependencyInjection {
    fun provideRepository(context: Context): JourneyRepository {
        // Membuat instance dari AppDatabase
        val database = AppDatabase.getDatabase(context)
        // Membuat instance dari AppExecutors
        val appExecutors = AppExecutors()
        // Mendapatkan instance dari AppDao dari AppDatabase
        val dao = database.PostDao()
        // Mendapatkan instance dari AppRepository menggunakan AppDao dan AppExecutors
        return JourneyRepository.getInstance(dao, appExecutors)
    }
}