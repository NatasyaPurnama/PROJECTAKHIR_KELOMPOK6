package com.example.tugasakhir.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.tugasakhir.R
import com.example.tugasakhir.data.api.APIResponse
import com.google.android.material.imageview.ShapeableImageView

class WisataAdapter(private val wisataList: List<APIResponse>) : RecyclerView.Adapter<WisataAdapter.ViewHolder>() {
    private lateinit var onItemClickCallback: OnItemClickCallback
    private var isLoved = false

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: APIResponse)
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nama: TextView = itemView.findViewById(R.id.namawisata)
        val lokasi: TextView = itemView.findViewById(R.id.lokasi)
        val rating: TextView = itemView.findViewById(R.id.rating)
        val img: ShapeableImageView = itemView.findViewById(R.id.imgwisata)
        val love: ImageView = itemView.findViewById(R.id.lovee)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.item_wisata, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = wisataList[position]

        holder.nama.text = data.nama_wisata
        holder.lokasi.text = data.lokasi
        holder.rating.text = data.rating+" / 5"

        Glide.with(holder.itemView)
            .load(data.gambar)
            .into(holder.img)

        holder.love.setOnClickListener {
            if (isLoved) {
                holder.love.setImageResource(R.drawable.ic_wlove)
                isLoved = false
            } else {
                holder.love.setImageResource(R.drawable.ic_rlove)
                isLoved = true
            }
        }

        holder.itemView.setOnClickListener { onItemClickCallback.onItemClicked(wisataList[holder.absoluteAdapterPosition]) }
    }

    override fun getItemCount(): Int = wisataList.size
}