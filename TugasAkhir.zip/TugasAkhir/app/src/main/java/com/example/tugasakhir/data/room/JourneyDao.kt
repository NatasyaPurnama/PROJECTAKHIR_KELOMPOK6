package com.example.tugasakhir.room

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface JourneyDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insertJourney(journeyEntity: JourneyEntity)

    @Query("SELECT * FROM journeyentity ORDER BY name ASC")
    fun getAllJourney() : LiveData<List<JourneyEntity>>

    @Delete
    fun deleteJourney(journeyEntity: JourneyEntity)

    @Update
    fun updateJourney(journeyEntity: JourneyEntity)
}