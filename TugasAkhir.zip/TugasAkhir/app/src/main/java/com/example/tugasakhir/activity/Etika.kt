package com.example.tugasakhir.activity

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.denzcoskun.imageslider.ImageSlider
import com.denzcoskun.imageslider.constants.ScaleTypes
import com.denzcoskun.imageslider.models.SlideModel
import com.example.tugasakhir.R
import com.example.tugasakhir.adapter.EtikaAdapter
import com.example.tugasakhir.adapter.ListAdapter
import com.example.tugasakhir.adapter.WisataAdapter
import com.example.tugasakhir.data.ListData
import com.example.tugasakhir.data.api.WisataViewModel
import com.google.android.material.bottomnavigation.BottomNavigationView

class Etika : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: EtikaAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_etika)

        imgSlider()
        data()

        val bottomNav = findViewById<BottomNavigationView>(R.id.nav)
        bottomNav.setOnNavigationItemSelectedListener(navListener)
        bottomNav.selectedItemId = R.id.nav_ethics
    }

    private fun data(){
        recyclerView = findViewById(R.id.rvEtika)
        adapter = EtikaAdapter(ListData.ListEtika)
        recyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        recyclerView.adapter = adapter
    }

    private fun imgSlider(){
        val imgSlider = findViewById<ImageSlider>(R.id.imgslider)
        val imgList = ArrayList<SlideModel>()

        imgList.add(SlideModel("https://firebasestorage.googleapis.com/v0/b/sriusnyoba.appspot.com/o/Goa%20Cerme.jpg?alt=media&token=f17f6fe7-5473-4cf8-9387-360c23219cb5"))
        imgList.add(SlideModel("https://firebasestorage.googleapis.com/v0/b/sriusnyoba.appspot.com/o/Air%20Terjun%20Sekumpul.jpg?alt=media&token=a0334470-773f-4d60-b93a-e823fd9e6f8f"))
        imgList.add(SlideModel("https://firebasestorage.googleapis.com/v0/b/sriusnyoba.appspot.com/o/gunung%20kerinci.jpg?alt=media&token=b9d8d0c7-f79d-4f75-a203-a0ec336a162d"))

        imgSlider.setImageList(imgList,ScaleTypes.FIT)
    }

    private val navListener = BottomNavigationView.OnNavigationItemSelectedListener { item: MenuItem ->
        when (item.itemId) {
            R.id.nav_ethics -> {
                true
            }
            R.id.nav_home -> {
                val intent = Intent(this, Home::class.java)
                startActivity(intent)
                true
            }
            R.id.nav_journey -> {
                val intent = Intent(this, Journey::class.java)
                startActivity(intent)
                true
            }
            R.id.nav_explore -> {
                val intent = Intent(this, Explore::class.java)
                startActivity(intent)
                true
            }
            R.id.nav_profile -> {
                val intent = Intent(this, Profile::class.java)
                startActivity(intent)
                true
            }
            else -> false
        }
    }
}