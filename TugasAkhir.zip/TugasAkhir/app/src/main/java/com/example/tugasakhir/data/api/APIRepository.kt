package com.example.tugasakhir.data.api

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class APIRepository { private val _listWisata = MutableLiveData<List<APIResponse>>()
    var listWisata: LiveData<List<APIResponse>> = _listWisata

    private var _isLoading = MutableLiveData<Boolean>()
    var isLoading: LiveData<Boolean> = _isLoading

    fun getAllWisata() {
        _isLoading.value = true
        val service = APIconfig.getApiService().getAllWisata()
        service.enqueue(object : Callback<List<APIResponse>> {
            override fun onResponse(
                call: Call<List<APIResponse>>,
                response: Response<List<APIResponse>>
            ) {
                _isLoading.value = false
                if (response.isSuccessful && response.body() != null) {
                    _listWisata.value = response.body()
                } else {
                    Log.e("Error on Response", "onFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<List<APIResponse>>, t: Throwable) {
                _isLoading.value = false
                Log.e("Error on Failure", "onFailure: ${t.message}")
            }
        })
    }
}
